param(
  [string]$ProjectPath = ".\formbhro_tools"
)
$ErrorActionPreference = "Stop"
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  throw "Flutter not found. Install Flutter and add flutter\bin to PATH first."
}
if (-not (Test-Path $ProjectPath)) {
  flutter create --org com.formbhro --project-name formbhro_tools $ProjectPath
}
$root = (Resolve-Path $ProjectPath).Path
$sourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Copy-Item (Join-Path $sourceRoot "pubspec.yaml") (Join-Path $root "pubspec.yaml") -Force
New-Item -ItemType Directory -Force (Join-Path $root "lib") | Out-Null
Copy-Item (Join-Path $sourceRoot "lib\main.dart") (Join-Path $root "lib\main.dart") -Force

$manifest = Join-Path $root "android\app\src\main\AndroidManifest.xml"
Copy-Item (Join-Path $sourceRoot "android_patch\app\src\main\AndroidManifest.xml") $manifest -Force

$kotlinDir = Join-Path $root "android\app\src\main\kotlin\com\formbhro\tools"
New-Item -ItemType Directory -Force $kotlinDir | Out-Null
Copy-Item (Join-Path $sourceRoot "android_patch\app\src\main\kotlin\com\formbhro\tools\MainActivity.kt") (Join-Path $kotlinDir "MainActivity.kt") -Force
Copy-Item (Join-Path $sourceRoot "android_patch\app\src\main\kotlin\com\formbhro\tools\OverlayService.kt") (Join-Path $kotlinDir "OverlayService.kt") -Force

$gradleKts = Join-Path $root "android\app\build.gradle.kts"
$gradleGroovy = Join-Path $root "android\app\build.gradle"
if (Test-Path $gradleKts) {
  $content = Get-Content $gradleKts -Raw
  $content = $content -replace 'namespace\s*=\s*"[^"]+"', 'namespace = "com.formbhro.tools"'
  $content = $content -replace 'applicationId\s*=\s*"[^"]+"', 'applicationId = "com.formbhro.tools"'
  Set-Content -Path $gradleKts -Value $content -Encoding UTF8
} elseif (Test-Path $gradleGroovy) {
  $content = Get-Content $gradleGroovy -Raw
  $content = $content -replace 'namespace\s+"[^"]+"', 'namespace "com.formbhro.tools"'
  $content = $content -replace 'applicationId\s+"[^"]+"', 'applicationId "com.formbhro.tools"'
  Set-Content -Path $gradleGroovy -Value $content -Encoding UTF8
}

Push-Location $root
try {
  flutter pub get
  Write-Host "`nFiles copied. Next run: flutter run" -ForegroundColor Green
} finally {
  Pop-Location
}
