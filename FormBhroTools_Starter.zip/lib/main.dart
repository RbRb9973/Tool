import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

void main() => runApp(const FormBhroToolsApp());

const _native = MethodChannel('formbhro/overlay');
const _shared = EventChannel('formbhro/share');

class FormBhroToolsApp extends StatelessWidget {
  const FormBhroToolsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FormBhro Tools',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF13B8A6),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF0B1020),
        useMaterial3: true,
      ),
      home: const ToolsHome(),
    );
  }
}

class ToolsHome extends StatefulWidget {
  const ToolsHome({super.key});

  @override
  State<ToolsHome> createState() => _ToolsHomeState();
}

class _ToolsHomeState extends State<ToolsHome> {
  String _status = 'Ready';
  String? _lastSharedPath;
  String? _lastSharedName;
  bool _overlayEnabled = false;
  static const _teal = Color(0xFF13B8A6);

  @override
  void initState() {
    super.initState();
    _listenForSharedFiles();
    _checkOverlay();
  }

  void _listenForSharedFiles() {
    _shared.receiveBroadcastStream().listen((event) {
      if (event is Map) {
        final path = event['path']?.toString();
        final name = event['name']?.toString() ?? 'Shared file';
        if (path != null && mounted) {
          setState(() {
            _lastSharedPath = path;
            _lastSharedName = name;
            _status = 'Received: $name';
          });
          _showSharedFileDialog(path, name);
        }
      }
    }, onError: (Object e) {
      if (mounted) setState(() => _status = 'Share receive error: $e');
    });
  }

  Future<void> _checkOverlay() async {
    try {
      final result = await _native.invokeMethod<bool>('hasOverlayPermission');
      if (mounted) setState(() => _overlayEnabled = result ?? false);
    } catch (_) {}
  }

  Future<void> _enableBubble() async {
    try {
      final granted = await _native.invokeMethod<bool>('requestOverlayPermission');
      if (granted == true) {
        await _native.invokeMethod('startOverlay');
        if (mounted) {
          setState(() {
            _overlayEnabled = true;
            _status = 'Floating ball enabled';
          });
        }
      } else {
        setState(() => _status = 'Allow “Display over other apps”, then return here');
      }
    } on PlatformException catch (e) {
      setState(() => _status = 'Overlay error: ${e.message}');
    }
  }

  Future<void> _stopBubble() async {
    try {
      await _native.invokeMethod('stopOverlay');
      if (mounted) setState(() {
        _overlayEnabled = false;
        _status = 'Floating ball stopped';
      });
    } catch (e) {
      setState(() => _status = 'Could not stop bubble: $e');
    }
  }

  Future<File?> _pickFile({required List<String> extensions}) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: extensions,
      withData: false,
    );
    final path = result?.files.single.path;
    if (path == null) return null;
    return File(path);
  }

  Future<Directory> _outputDir() async {
    final dir = await getApplicationDocumentsDirectory();
    final out = Directory('${dir.path}/FormBhroTools');
    if (!await out.exists()) await out.create(recursive: true);
    return out;
  }

  Future<void> _resizeOrCompress({required bool compressOnly}) async {
    try {
      final file = await _pickFile(extensions: ['jpg', 'jpeg', 'png', 'webp']);
      if (file == null) return;
      final bytes = await file.readAsBytes();
      final decoded = img.decodeImage(bytes);
      if (decoded == null) throw Exception('Unsupported or damaged image');

      int width = decoded.width;
      int height = decoded.height;
      int quality = 82;
      if (!compressOnly) {
        final sizeController = TextEditingController(text: '1200');
        final chosen = await showDialog<int>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Resize image'),
            content: TextField(
              controller: sizeController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Maximum width/height in pixels',
                hintText: '1200',
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, int.tryParse(sizeController.text) ?? 1200),
                child: const Text('Resize'),
              ),
            ],
          ),
        );
        if (chosen == null) return;
        final maxSide = chosen.clamp(64, 8000);
        if (width >= height && width > maxSide) {
          height = (height * maxSide / width).round();
          width = maxSide;
        } else if (height > width && height > maxSide) {
          width = (width * maxSide / height).round();
          height = maxSide;
        }
      }

      final processed = (width == decoded.width && height == decoded.height)
          ? decoded
          : img.copyResize(decoded, width: width, height: height);
      final outDir = await _outputDir();
      final outputPath = '${outDir.path}/${compressOnly ? "compressed" : "resized"}_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final outputBytes = img.encodeJpg(processed, quality: quality);
      final output = File(outputPath);
      await output.writeAsBytes(outputBytes, flush: true);
      if (!mounted) return;
      setState(() => _status = 'Saved ${output.lengthSync()} bytes');
      await _resultDialog(output, compressOnly ? 'Compressed image' : 'Resized image');
    } catch (e) {
      _message('Image tool failed: $e');
    }
  }

  Future<void> _whiteCanvas() async {
    try {
      final file = await _pickFile(extensions: ['jpg', 'jpeg', 'png', 'webp']);
      if (file == null) return;
      final bytes = await file.readAsBytes();
      final source = img.decodeImage(bytes);
      if (source == null) throw Exception('Could not decode image');
      // This creates a white canvas behind the entire original image.
      // It does NOT remove an existing background; segmentation can be added later.
      final canvas = img.Image(width: source.width, height: source.height);
      img.fill(canvas, color: img.ColorRgb8(255, 255, 255));
      img.compositeImage(canvas, source);
      final outDir = await _outputDir();
      final output = File('${outDir.path}/white_canvas_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await output.writeAsBytes(img.encodeJpg(canvas, quality: 92), flush: true);
      if (!mounted) return;
      await _resultDialog(output, 'White canvas image');
      setState(() => _status = 'White canvas saved (background not removed)');
    } catch (e) {
      _message('White canvas failed: $e');
    }
  }

  Future<void> _signatureTool() async {
    try {
      final file = await _pickFile(extensions: ['jpg', 'jpeg', 'png', 'webp']);
      if (file == null) return;
      final source = img.decodeImage(await file.readAsBytes());
      if (source == null) throw Exception('Could not decode image');
      final resized = img.copyResize(source, width: 600);
      final outDir = await _outputDir();
      final output = File('${outDir.path}/signature_${DateTime.now().millisecondsSinceEpoch}.png');
      await output.writeAsBytes(img.encodePng(resized), flush: true);
      await _resultDialog(output, 'Signature resized to 600 px wide');
      setState(() => _status = 'Signature image saved');
    } catch (e) {
      _message('Signature tool failed: $e');
    }
  }

  Future<void> _pdfTool() async {
    final file = await _pickFile(extensions: ['pdf']);
    if (file == null) return;
    await _resultDialog(file, 'Selected PDF');
    if (mounted) setState(() => _status = 'PDF selected: ${file.path.split(Platform.pathSeparator).last}');
  }

  Future<void> _showSharedFileDialog(String path, String name) async {
    if (!mounted) return;
    final file = File(path);
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('File received'),
        content: Text('$name\n\nChoose what to do with this file.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
          if (name.toLowerCase().endsWith('.pdf'))
            FilledButton(onPressed: () async {
              Navigator.pop(ctx);
              await Share.shareXFiles([XFile(file.path)], text: 'Shared from FormBhro Tools');
            }, child: const Text('Share PDF')),
          if (RegExp(r'\.(png|jpe?g|webp)$', caseSensitive: false).hasMatch(name))
            FilledButton(onPressed: () async {
              Navigator.pop(ctx);
              await _processSharedImage(file);
            }, child: const Text('Resize image')),
          TextButton(onPressed: () async {
            Navigator.pop(ctx);
            await Share.shareXFiles([XFile(file.path)], text: 'Shared from FormBhro Tools');
          }, child: const Text('Share onward')),
        ],
      ),
    );
  }

  Future<void> _processSharedImage(File file) async {
    try {
      final decoded = img.decodeImage(await file.readAsBytes());
      if (decoded == null) throw Exception('Unsupported image');
      final resized = img.copyResize(decoded, width: decoded.width > 1200 ? 1200 : decoded.width);
      final dir = await _outputDir();
      final out = File('${dir.path}/shared_resized_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await out.writeAsBytes(img.encodeJpg(resized, quality: 82), flush: true);
      await _resultDialog(out, 'Processed shared image');
    } catch (e) {
      _message('Could not process shared image: $e');
    }
  }

  Future<void> _resultDialog(File file, String title) async {
    if (!mounted) return;
    final size = await file.length();
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text('Saved successfully.\n${file.path}\n\nSize: $size bytes'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
          FilledButton.icon(
            onPressed: () {
              Navigator.pop(ctx);
              Share.shareXFiles([XFile(file.path)], text: 'Created with FormBhro Tools');
            },
            icon: const Icon(Icons.share),
            label: const Text('Share file'),
          ),
        ],
      ),
    );
  }

  void _message(String text) {
    if (!mounted) return;
    setState(() => _status = text);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    final items = <_ToolItem>[
      _ToolItem('Image Resizer', 'Change dimensions', Icons.photo_size_select_large, () => _resizeOrCompress(compressOnly: false)),
      _ToolItem('White Background', 'Create white canvas', Icons.layers, _whiteCanvas),
      _ToolItem('Image Compressor', 'Save smaller JPG', Icons.compress, () => _resizeOrCompress(compressOnly: true)),
      _ToolItem('Signature Tool', 'Resize signature image', Icons.draw, _signatureTool),
      _ToolItem('PDF Tools', 'Select and share PDF', Icons.picture_as_pdf, _pdfTool),
      _ToolItem('File Share', 'Receive and share files', Icons.ios_share, () async {
        if (_lastSharedPath != null) {
          await Share.shareXFiles([XFile(_lastSharedPath!)], text: 'Shared from FormBhro Tools');
        } else {
          _message('Use Share from another app and choose FormBhro Tools.');
        }
      }),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.bolt, color: _teal),
          SizedBox(width: 8),
          Text('FormBhro Tools', style: TextStyle(fontWeight: FontWeight.w800)),
        ]),
        actions: [
          IconButton(
            tooltip: _overlayEnabled ? 'Stop floating ball' : 'Enable floating ball',
            onPressed: _overlayEnabled ? _stopBubble : _enableBubble,
            icon: Icon(_overlayEnabled ? Icons.bubble_chart : Icons.circle_outlined),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF123B46), Color(0xFF17213A)]),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: _teal.withValues(alpha: .35)),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Your tools. One tap away.', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(_status, style: TextStyle(color: Colors.white.withValues(alpha: .75))),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _overlayEnabled ? _stopBubble : _enableBubble,
                    icon: Icon(_overlayEnabled ? Icons.stop_circle_outlined : Icons.open_in_new),
                    label: Text(_overlayEnabled ? 'Turn off floating ball' : 'Enable floating ball'),
                  ),
                ),
              ]),
            ),
            const SizedBox(height: 22),
            const Text('QUICK TOOLS', style: TextStyle(letterSpacing: 1.6, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: items.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.05,
              ),
              itemBuilder: (context, index) {
                final item = items[index];
                return InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: item.onTap,
                  child: Ink(
                    decoration: BoxDecoration(
                      color: const Color(0xFF141B2D),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.white.withValues(alpha: .08)),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(color: _teal.withValues(alpha: .14), borderRadius: BorderRadius.circular(12)),
                          child: Icon(item.icon, color: _teal, size: 25),
                        ),
                        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(item.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                          const SizedBox(height: 4),
                          Text(item.subtitle, style: TextStyle(fontSize: 12, color: Colors.white.withValues(alpha: .62))),
                        ]),
                      ]),
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 18),
            if (_lastSharedName != null)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.attach_file, color: _teal),
                  title: Text(_lastSharedName!, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: const Text('Last received file'),
                  trailing: IconButton(
                    icon: const Icon(Icons.share),
                    onPressed: () => Share.shareXFiles([XFile(_lastSharedPath!)]),
                  ),
                ),
              ),
            const SizedBox(height: 8),
            Text(
              'Note: White Background currently creates a white canvas; it does not automatically erase the photo background. PDF Tools currently receives/selects and shares PDFs.',
              style: TextStyle(fontSize: 12, color: Colors.white.withValues(alpha: .55)),
            ),
          ],
        ),
      ),
    );
  }
}

class _ToolItem {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;
  _ToolItem(this.title, this.subtitle, this.icon, this.onTap);
}
