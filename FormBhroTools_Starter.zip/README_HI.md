# FormBhro Tools — Android starter

Yeh runnable **starter source pack** hai, complete generated Flutter project nahin. Flutter/Android Gradle ki machine-specific generated files ko `flutter create` se banaya jayega, phir is pack ki files copy hongi.

## Is version mein kya kaam karta hai
- Dark FormBhro Tools dashboard
- Native Android floating `FB` ball; drag kar sakte hain; tap se app khulti hai
- Android share intents se single image/PDF/octet-stream aur multiple images receive karna
- Received files ko app cache mein copy karna
- Image resize aur JPEG compression
- White canvas output (existing photo background erase **nahi** karta)
- Signature image ko 600px width par resize karke PNG save karna
- PDF select karna aur file share karna

## Requirements
- Windows 11
- Flutter stable SDK, Android Studio, Android SDK
- Android phone with USB debugging, or emulator
- Package/application ID: `com.formbhro.tools`

## A. Check environment
PowerShell mein:
```powershell
flutter doctor
```
Android licenses accept karein:
```powershell
flutter doctor --android-licenses
```

## B. Project generate karein
PowerShell mein us folder mein jaayein jahan project rakhna hai:
```powershell
flutter create --org com.formbhro --project-name formbhro_tools formbhro_tools
cd formbhro_tools
```
`android/app/src/main/kotlin/` mein Flutter ne jo default `MainActivity.kt` banayi hai, use replace karein. Package path is starter ke mutabik hona chahiye:
`android/app/src/main/kotlin/com/formbhro/tools/`

## C. Starter files copy karein
Is ZIP ke `lib/main.dart` aur `pubspec.yaml` ko project root ke andar copy/replace karein.
ZIP ke `android_patch/app/src/main/AndroidManifest.xml` ko `android/app/src/main/AndroidManifest.xml` par copy karein.
ZIP ke dono Kotlin files ko:
- `android/app/src/main/kotlin/com/formbhro/tools/MainActivity.kt`
- `android/app/src/main/kotlin/com/formbhro/tools/OverlayService.kt`
par copy karein.

### IMPORTANT: Gradle namespace/applicationId
Open `android/app/build.gradle.kts` (ya `build.gradle`) and set:
```kotlin
android {
    namespace = "com.formbhro.tools"
    defaultConfig {
        applicationId = "com.formbhro.tools"
    }
}
```
Agar aapke generated Gradle file mein syntax alag ho, existing syntax hi rakhein aur sirf namespace/applicationId update karein.

## D. Build
```powershell
flutter pub get
flutter analyze
flutter run
```
Phone par install karne ke liye:
- Developer options > USB debugging ON
- USB se connect karein
- `flutter devices` se device check karein
- `flutter run`

APK:
```powershell
flutter build apk --debug
```
APK path:
`build\app\outputs\flutter-apk\app-debug.apk`

## E. Floating ball enable karein
1. App open karein.
2. `Enable floating ball` tap karein.
3. Android Settings khulengi. `Display over other apps` / `Appear on top` permission allow karein.
4. FormBhro Tools par wapas aakar button dobara tap karein.
5. Floating FB ball doosri apps ke upar dikhegi. Kuch secure screens/apps/Android system screens overlay ko block ya hide kar sakti hain.
6. Stop karne ke liye app ke button se service band karein.

## F. Test file sharing
1. Gallery mein image kholein > Share > FormBhro Tools.
2. App receive dialog mein `Resize image` ya `Share onward` choose karein.
3. Files app se PDF share karein > FormBhro Tools; app file receive karke onward share kar sakti hai.

## Known limitations (honest MVP scope)
- White Background tool abhi plain white canvas banata hai. Subject segmentation/background removal AI abhi included nahi.
- PDF tool abhi PDF select/receive/share karta hai; merge, split, compress ya edit abhi implemented nahi.
- Signature tool image resize karta hai; transparent-background cleanup/crop UI abhi included nahi.
- Shared image/PDF receive is supported; every file type or every source app is not guaranteed.
- Foreground service uses Android's `specialUse` service type; newer Android versions and OEMs can have extra restrictions. For Play Store publishing, review current Google Play foreground-service policy and provide required disclosures.
- For release, add proper launcher icon, app privacy policy, service disclosure, tests and signing config.
